# Claude Yandex Skills

Набор скиллов для [Claude Code](https://claude.com/claude-code) и [Claude Agent SDK](https://docs.anthropic.com/en/api/agent-sdk/overview), которые дают ассистенту доступ к рекламным и SEO-сервисам Яндекса через их официальные API.

Скиллы автоматически подгружаются Claude, когда задача совпадает с их описанием: «проверь спрос в Wordstat», «подними кампанию в Директе», «посмотри конверсии в Метрике» и т. п. Внутри каждого скилла лежат shell-скрипты, которые ходят в API, кешируют результаты и отдают компактные сводки — без переполнения контекстного окна.

---

## 📦 Что внутри

| Скилл | Что делает | Основные сценарии |
|---|---|---|
| [**yandex-direct**](./yandex-direct) | Яндекс.Директ API v5 | Создание и управление кампаниями, ставки, статистика, массовая загрузка объявлений и ключей |
| [**yandex-metrika**](./yandex-metrika) | Yandex Metrika API | Трафик, конверсии, воронки, UTM, поисковые запросы, custom-отчёты |
| [**yandex-webmaster**](./yandex-webmaster) | Yandex Webmaster API | Индексация, sitemap, переобход, поисковые запросы, диагностика сайта |
| [**yandex-wordstat**](./yandex-wordstat) | Yandex Wordstat API | Анализ спроса, семантическое ядро, частотность, сезонность, регионы |
| [**yandex-search-api**](./yandex-search-api) | Yandex Cloud Search API v2 | Парсинг выдачи Яндекса (SERP), синхронный и асинхронный режимы |

Все скиллы написаны в cache-first парадигме: повторные запросы отдаются из локального кеша, чтобы экономить контекст и деньги.

---

## 🚀 Как использовать

### 1. Клонировать в каталог скиллов Claude Code

```bash
# Глобально для всех проектов
cd ~/.claude/skills
git clone https://github.com/YOUR_USERNAME/claude-yandex-skills.git
# Потом переместить каждый скилл в корень ~/.claude/skills/
```

Или поместить в проект:

```bash
cd ~/your-project/.claude/skills
git clone https://github.com/YOUR_USERNAME/claude-yandex-skills.git
```

### 2. Получить токены и положить в `config/`

Каждый скилл требует свои credentials — **их нужно получить самостоятельно**. В каждой директории есть `config/README.md` с пошаговой инструкцией и `config/.env.example` как шаблон.

**Коротко, какие токены где нужны:**

- **Direct / Metrika / Webmaster** — OAuth-токен через [oauth.yandex.ru](https://oauth.yandex.ru/) для приложения с нужными scope'ами (инструкция в каждом `config/README.md`).
- **Wordstat** — OAuth-токен Яндекс.Директ с включённым доступом к Wordstat (доступ выдаётся модерацией).
- **Yandex Search API** — сервисный аккаунт в [Yandex Cloud](https://cloud.yandex.ru/) + каталог + JSON-ключ сервисного аккаунта.

### 3. Использовать в Claude Code

После установки скилл активируется автоматически, когда промпт совпадает с его описанием. Примеры:

```
«посмотри в Wordstat спрос на "нейросеть без vpn" по регионам РФ»
→ сработает yandex-wordstat

«создай объявление в Директе для кампании ng_b2c с ценой клика 15₽»
→ сработает yandex-direct

«сколько регистраций было с Яндекс.Директа за последнюю неделю по UTM»
→ сработает yandex-metrika

«попроси переобход новой статьи в Вебмастере»
→ сработает yandex-webmaster

«пробей топ-10 в Яндексе по запросу "chatgpt без vpn"»
→ сработает yandex-search-api
```

---

## 🗂 Структура каждого скилла

```
yandex-<name>/
├── SKILL.md              ← манифест с триггерами и описанием
├── .gitignore
├── config/
│   ├── .env.example      ← шаблон с переменными
│   └── README.md         ← инструкция как получить токены
├── references/           ← справочники (endpoints, поля API, кейсы)
└── scripts/              ← shell-скрипты, которые вызываются Claude
    ├── common.sh         ← общие хелперы (auth, jq, curl)
    └── <action>.sh       ← конкретные действия (например, popular_queries.sh)
```

Claude читает `SKILL.md` для описания возможностей, а затем сам решает, какие `scripts/*.sh` запустить под задачу. Все скрипты спроектированы как CLI с понятными флагами и JSON-выводом.

---

## 🔒 Безопасность

- Скиллы не содержат секретов в репозитории. Все токены — только в локальных `config/.env`, которые добавлены в `.gitignore`.
- Не коммитьте свои `config/.env`, `config/service_account_key.json`, `config/config.json` — они игнорируются по умолчанию.
- Кеш (`cache/`) тоже в `.gitignore`, чтобы не тащить в репо чужие сервисные данные.

---

## 🛠 Требования

- **bash** / zsh
- **curl** — HTTP-запросы к API
- **jq** — парсинг JSON-ответов
- Для `yandex-search-api` — Python 3 для генерации JWT-подписи к IAM-токену

Установка на macOS:

```bash
brew install jq
```

На Ubuntu/Debian:

```bash
sudo apt install jq
```

---

## 📝 Лицензия

MIT. Форкайте, адаптируйте, делайте PR с улучшениями.

---

## 👤 Автор

Максим Соловьёв — [msolo.me](https://msolo.me) · [ng-ai.ru](https://ng-ai.ru)

Если используете эти скиллы в своих проектах или нашли баг — напишите, будет приятно.
