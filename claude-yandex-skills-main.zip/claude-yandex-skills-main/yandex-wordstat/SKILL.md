---
name: yandex-wordstat
description: |
  Анализ поискового спроса через Yandex Wordstat API.
  Используй когда нужно: исследовать спрос, семантическое ядро,
  частотность запросов, сезонность или региональный спрос.
  Triggers: "wordstat", "спрос", "семантика", "частотность", "ключевые слова", "упущенный спрос".
---

# Yandex Wordstat

Анализ поискового спроса через Yandex Wordstat API.

## Скрипты

Скрипты расположены в: `~/.openclaw/workspace/skills/yandex-wordstat/scripts/`
Конфиг: `~/.openclaw/workspace/skills/yandex-wordstat/config/.env`

### Перед запуском
```bash
cd ~/.openclaw/workspace/skills/yandex-wordstat
```

### Доступные скрипты

| Скрипт | Что делает |
|--------|------------|
| `scripts/quota.sh` | Проверить API-соединение |
| `scripts/top_requests.sh` | Топ фраз (до 2000, CSV) |
| `scripts/dynamics.sh` | Динамика по времени |
| `scripts/regions_stats.sh` | Региональный спрос |
| `scripts/regions_tree.sh` | Список ID регионов |
| `scripts/search_region.sh` | Найти ID региона по названию |

### Примеры
```bash
# Проверка
bash scripts/quota.sh

# Топ запросов
bash scripts/top_requests.sh --phrase "chatgpt" --regions "213" --limit 500 --csv report.csv

# Динамика
bash scripts/dynamics.sh --phrase "chatgpt" --period "monthly" --from-date "2025-01-01"

# Регионы
bash scripts/regions_stats.sh --phrase "chatgpt" --region-type "cities"
```

## Операторы Wordstat

- `"запрос"` — точная фраза (без доп. слов)
- `!слово` — фиксация формы слова
- `-слово` — исключить
- `(a|b|c)` — группировка вариантов
- Предлоги фиксировать через `!`: `юрист !по дтп`

## КРИТИЧЕСКИ ВАЖНО: верификация интента

**Перед каждым анализом:**
1. Спроси регион и подожди ответа
2. Уточни, что именно продаёт/рекламирует пользователь
3. Для каждого перспективного запроса — WebSearch для проверки, что люди реально хотят КУПИТЬ
4. Разделяй отчёт на целевые/нецелевые с обоснованием

## Популярные регионы

| Регион | ID |
|--------|-----|
| Россия | 225 |
| Москва | 213 |
| Москва и область | 1 |
| СПб | 2 |

## Лимиты
- 10 запросов/сек, 1000 запросов/день
