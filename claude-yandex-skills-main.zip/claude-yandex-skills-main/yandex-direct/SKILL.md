---
name: yandex-direct
description: |
  Управление рекламными кампаниями Яндекс.Директ через API v5.
  Кампании, объявления, ключевые слова, бюджеты, статистика.
  Cache-first подход для гигиены контекстного окна.
  Triggers: "яндекс директ", "директ кампании", "директ статистика",
  "управление рекламой", "включить кампанию", "бюджет кампании",
  "выключить кампанию", "объявления директ", "ключевые слова директ".
---

# Yandex Direct

Управление рекламными кампаниями через Яндекс.Директ API v5.

## Скрипты

Скрипты расположены в: `~/.claude/skills/yandex-direct/scripts/`
Конфиг: `~/.claude/skills/yandex-direct/config/.env`

### Перед запуском
```bash
cd ~/.claude/skills/yandex-direct
```

### Доступные скрипты

| Скрипт | Что делает |
|--------|------------|
| `scripts/campaigns.sh` | Список кампаний с статусами и бюджетами |
| `scripts/campaign_on.sh` | Включить кампанию(и) |
| `scripts/campaign_off.sh` | Выключить кампанию(и) |
| `scripts/campaign_budget.sh` | Установить дневной бюджет |
| `scripts/ads.sh` | Список объявлений в кампании |
| `scripts/keywords.sh` | Ключевые фразы кампании/группы |
| `scripts/groups.sh` | Группы объявлений кампании |
| `scripts/stats.sh` | Статистика за период (TSV отчёт) |
| `scripts/balance.sh` | Баланс аккаунта и расход |

### Примеры
```bash
# Список всех кампаний
bash scripts/campaigns.sh

# Только активные
bash scripts/campaigns.sh --status ON

# CSV-экспорт
bash scripts/campaigns.sh --csv campaigns.csv

# Включить/выключить кампанию
bash scripts/campaign_on.sh --id 123456
bash scripts/campaign_off.sh --id 123456,789012

# Установить бюджет 1000₽/день
bash scripts/campaign_budget.sh --id 123456 --amount 1000

# Объявления кампании
bash scripts/ads.sh --campaign-id 123456

# Ключевые слова
bash scripts/keywords.sh --campaign-id 123456

# Группы объявлений
bash scripts/groups.sh --campaign-id 123456

# Статистика за период
bash scripts/stats.sh --date1 2026-03-01 --date2 2026-03-31
bash scripts/stats.sh --campaign-id 123456 --date1 2026-03-01 --date2 2026-03-31 --group-by DAY --csv stats.csv

# Баланс
bash scripts/balance.sh
```

## API

- **Base URL:** `https://api.direct.yandex.com/json/v5/`
- **Auth:** `Authorization: Bearer <token>`
- **Format:** POST с JSON `{"method": "...", "params": {...}}`
- **Reports:** POST к `/json/v5/reports` с TSV ответом
- **Деньги:** API работает в микрорублях (×1 000 000), скрипты показывают в рублях

## Лимиты
- Основные методы: ~5-10 запросов/сек
- Reports: ~5 одновременных, retry на 201/202 (PENDING/CREATING)
- При 429 — автоматический retry с backoff
