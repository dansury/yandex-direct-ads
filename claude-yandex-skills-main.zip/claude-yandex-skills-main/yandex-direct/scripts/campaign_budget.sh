#!/bin/sh
# Set daily budget for campaign
. "$(dirname "$0")/common.sh"

CID=""
AMOUNT=""
MODE="DISTRIBUTED"
while [ $# -gt 0 ]; do
  case "$1" in
    --id) CID="$2"; shift 2 ;;
    --amount) AMOUNT="$2"; shift 2 ;;
    --mode) MODE="$2"; shift 2 ;;
    *) shift ;;
  esac
done

if [ -z "$CID" ] || [ -z "$AMOUNT" ]; then
  echo "Usage: campaign_budget.sh --id 123456 --amount 1500 [--mode DISTRIBUTED|STANDARD]" >&2
  exit 1
fi

# Convert rubles to micros
MICROS=$(python3 -c "print(int($AMOUNT * 1000000))")

BODY="{\"method\":\"update\",\"params\":{\"Campaigns\":[{\"Id\":$CID,\"DailyBudget\":{\"Amount\":$MICROS,\"Mode\":\"$MODE\"}}]}}"
RESP=$(direct_request "campaigns" "$BODY")

echo "$RESP" | python3 -c "
import json, sys
data = json.load(sys.stdin)
results = data.get('result', {}).get('UpdateResults', [])
for r in results:
    cid = r.get('Id', '?')
    errors = r.get('Errors', [])
    if errors:
        for e in errors:
            print(f'ERROR campaign {cid}: {e.get(\"Message\",\"?\")}')
    else:
        print(f'OK campaign {cid}: budget set to ${AMOUNT}₽/day ({\"$MODE\"})')
"
