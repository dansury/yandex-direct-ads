#!/bin/sh
# Campaign statistics report (TSV via Reports API)
. "$(dirname "$0")/common.sh"

CAMPAIGN_ID=""
DATE1=""
DATE2=""
GROUP_BY="AUTO"
CSV_FILE=""
while [ $# -gt 0 ]; do
  case "$1" in
    --campaign-id) CAMPAIGN_ID="$2"; shift 2 ;;
    --date1) DATE1="$2"; shift 2 ;;
    --date2) DATE2="$2"; shift 2 ;;
    --group-by) GROUP_BY="$2"; shift 2 ;;
    --csv) CSV_FILE="$2"; shift 2 ;;
    *) shift ;;
  esac
done

if [ -z "$DATE1" ] || [ -z "$DATE2" ]; then
  echo "Usage: stats.sh --date1 2026-03-01 --date2 2026-03-31 [--campaign-id 123] [--group-by DAY|WEEK|MONTH] [--csv stats.csv]" >&2
  exit 1
fi

# Build filter
if [ -n "$CAMPAIGN_ID" ]; then
  FILTER=",\"Filter\":[{\"Field\":\"CampaignId\",\"Operator\":\"EQUALS\",\"Values\":[\"$CAMPAIGN_ID\"]}]"
else
  FILTER=""
fi

REPORT_NAME="stats_$(date +%s)"

BODY="{\"params\":{\"SelectionCriteria\":{\"DateFrom\":\"$DATE1\",\"DateTo\":\"$DATE2\"${FILTER}},\"FieldNames\":[\"Date\",\"CampaignName\",\"Impressions\",\"Clicks\",\"Ctr\",\"AvgCpc\",\"Cost\",\"Conversions\",\"CostPerConversion\"],\"ReportName\":\"$REPORT_NAME\",\"ReportType\":\"CAMPAIGN_PERFORMANCE_REPORT\",\"DateRangeType\":\"CUSTOM_DATE\",\"Format\":\"TSV\",\"IncludeVAT\":\"YES\",\"IncludeDiscount\":\"NO\"}}"

RESP=$(direct_report "$BODY")

if [ -n "$CSV_FILE" ]; then
  echo "$RESP" > "$CSV_FILE"
  echo "Report saved: $CSV_FILE"
fi

# Pretty print TSV
echo "$RESP" | python3 -c "
import sys
lines = sys.stdin.read().strip().split('\n')
if not lines:
    print('No data')
    sys.exit()
for i, line in enumerate(lines):
    cols = line.split('\t')
    if i == 0:
        print('\t'.join(cols))
        print('-' * 120)
    else:
        # Format cost from micros if numeric
        formatted = []
        for j, c in enumerate(cols):
            formatted.append(c)
        print('\t'.join(formatted))
print(f'\n{len(lines)-1} строк')
"
