#!/bin/sh
# Suspend (disable) campaign(s)
. "$(dirname "$0")/common.sh"

IDS=""
while [ $# -gt 0 ]; do
  case "$1" in
    --id) IDS="$2"; shift 2 ;;
    *) shift ;;
  esac
done

if [ -z "$IDS" ]; then
  echo "Usage: campaign_off.sh --id 123456[,789012]" >&2
  exit 1
fi

ID_ARRAY=$(echo "$IDS" | python3 -c "import sys; print('[' + ','.join(sys.stdin.read().strip().split(',')) + ']')")

BODY="{\"method\":\"suspend\",\"params\":{\"SelectionCriteria\":{\"Ids\":$ID_ARRAY}}}"
RESP=$(direct_request "campaigns" "$BODY")

echo "$RESP" | python3 -c "
import json, sys
data = json.load(sys.stdin)
results = data.get('result', {})
for r in results.get('SuspendResults', []):
    cid = r.get('Id', '?')
    errors = r.get('Errors', [])
    if errors:
        for e in errors:
            print(f'ERROR campaign {cid}: {e.get(\"Message\",\"?\")}')
    else:
        print(f'OK campaign {cid} suspended')
"
