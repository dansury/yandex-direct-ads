#!/bin/sh
# List ad groups
. "$(dirname "$0")/common.sh"

CAMPAIGN_ID=""
CSV_FILE=""
while [ $# -gt 0 ]; do
  case "$1" in
    --campaign-id) CAMPAIGN_ID="$2"; shift 2 ;;
    --csv) CSV_FILE="$2"; shift 2 ;;
    *) shift ;;
  esac
done

if [ -z "$CAMPAIGN_ID" ]; then
  echo "Usage: groups.sh --campaign-id 123456 [--csv groups.csv]" >&2
  exit 1
fi

BODY="{\"method\":\"get\",\"params\":{\"SelectionCriteria\":{\"CampaignIds\":[$CAMPAIGN_ID]},\"FieldNames\":[\"Id\",\"Name\",\"CampaignId\",\"Status\",\"ServingStatus\",\"NegativeKeywords\"]}}"
RESP=$(direct_request "adgroups" "$BODY")

echo "$RESP" | python3 -c "
import json, sys
data = json.load(sys.stdin)
groups = data.get('result', {}).get('AdGroups', [])
csv_file = '$CSV_FILE'

print(f'{'ID':<12} {'Название':<40} {'Статус':<12} {'Показы':<12} {'Минус-слова'}')
print('-' * 100)
for g in groups:
    gid = g['Id']
    name = g.get('Name', '?')
    status = g.get('Status', '?')
    serving = g.get('ServingStatus', '?')
    neg = ', '.join(g.get('NegativeKeywords', {}).get('Items', [])[:5])
    if len(g.get('NegativeKeywords', {}).get('Items', [])) > 5:
        neg += '...'
    print(f'{gid:<12} {name:<40} {status:<12} {serving:<12} {neg}')
print(f'\nВсего: {len(groups)} групп')

if csv_file:
    with open(csv_file, 'w', encoding='utf-8-sig') as f:
        f.write('ID;Название;Статус;Показы;Минус-слова\n')
        for g in groups:
            neg = '|'.join(g.get('NegativeKeywords', {}).get('Items', []))
            f.write(f'{g[\"Id\"]};{g.get(\"Name\",\"\")};{g.get(\"Status\",\"\")};{g.get(\"ServingStatus\",\"\")};{neg}\n')
    print(f'CSV: {csv_file}')
"
