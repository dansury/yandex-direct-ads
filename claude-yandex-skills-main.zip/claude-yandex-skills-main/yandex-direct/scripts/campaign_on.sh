#!/bin/sh
# Resume (enable) campaign(s)
. "$(dirname "$0")/common.sh"

IDS=""
while [ $# -gt 0 ]; do
  case "$1" in
    --id) IDS="$2"; shift 2 ;;
    *) shift ;;
  esac
done

if [ -z "$IDS" ]; then
  echo "Usage: campaign_on.sh --id 123456[,789012]" >&2
  exit 1
fi

# Build JSON array of IDs
ID_ARRAY=$(echo "$IDS" | python3 -c "import sys; print('[' + ','.join(sys.stdin.read().strip().split(',')) + ']')")

BODY="{\"method\":\"resume\",\"params\":{\"SelectionCriteria\":{\"Ids\":$ID_ARRAY}}}"
RESP=$(direct_request "campaigns" "$BODY")

echo "$RESP" | python3 -c "
import json, sys
data = json.load(sys.stdin)
results = data.get('result', {})
resumed = results.get('ResumeResults', [])
for r in resumed:
    cid = r.get('Id', '?')
    errors = r.get('Errors', [])
    warnings = r.get('Warnings', [])
    if errors:
        for e in errors:
            print(f'ERROR campaign {cid}: {e.get(\"Message\",\"?\")}')
    elif warnings:
        for w in warnings:
            print(f'WARNING campaign {cid}: {w.get(\"Message\",\"?\")}')
        print(f'OK campaign {cid} resumed (with warnings)')
    else:
        print(f'OK campaign {cid} resumed')
"
