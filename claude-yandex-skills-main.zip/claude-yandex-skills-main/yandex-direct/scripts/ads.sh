#!/bin/sh
# List ads in campaign
. "$(dirname "$0")/common.sh"

CAMPAIGN_ID=""
CSV_FILE=""
while [ $# -gt 0 ]; do
  case "$1" in
    --campaign-id) CAMPAIGN_ID="$2"; shift 2 ;;
    --csv) CSV_FILE="$2"; shift 2 ;;
    *) shift ;;
  esac
done

if [ -z "$CAMPAIGN_ID" ]; then
  echo "Usage: ads.sh --campaign-id 123456 [--csv ads.csv]" >&2
  exit 1
fi

BODY="{\"method\":\"get\",\"params\":{\"SelectionCriteria\":{\"CampaignIds\":[$CAMPAIGN_ID]},\"FieldNames\":[\"Id\",\"AdGroupId\",\"Status\",\"State\",\"StatusClarification\",\"Type\"],\"TextAdFieldNames\":[\"Title\",\"Title2\",\"Text\",\"Href\",\"Mobile\"]}}"
RESP=$(direct_request "ads" "$BODY")

echo "$RESP" | python3 -c "
import json, sys
data = json.load(sys.stdin)
ads = data.get('result', {}).get('Ads', [])
csv_file = '$CSV_FILE'

print(f'{'ID':<12} {'Группа':<12} {'Статус':<12} {'Тип':<8} {'Заголовок':<35} {'Mobile'}')
print('-' * 95)
for a in ads:
    aid = a['Id']
    gid = a.get('AdGroupId', '?')
    status = a.get('Status', '?')
    atype = a.get('Type', '?')
    ta = a.get('TextAd', {})
    title = ta.get('Title', '—')[:33]
    mobile = 'Да' if ta.get('Mobile', 'NO') == 'YES' else ''
    print(f'{aid:<12} {gid:<12} {status:<12} {atype:<8} {title:<35} {mobile}')
print(f'\nВсего: {len(ads)} объявлений')

if csv_file:
    with open(csv_file, 'w', encoding='utf-8-sig') as f:
        f.write('ID;Группа;Статус;Тип;Заголовок;Заголовок2;Текст;URL;Mobile\n')
        for a in ads:
            ta = a.get('TextAd', {})
            f.write(f'{a[\"Id\"]};{a.get(\"AdGroupId\",\"\")};{a.get(\"Status\",\"\")};{a.get(\"Type\",\"\")};{ta.get(\"Title\",\"\")};{ta.get(\"Title2\",\"\")};{ta.get(\"Text\",\"\")};{ta.get(\"Href\",\"\")};{ta.get(\"Mobile\",\"\")}\n')
    print(f'CSV: {csv_file}')
"
