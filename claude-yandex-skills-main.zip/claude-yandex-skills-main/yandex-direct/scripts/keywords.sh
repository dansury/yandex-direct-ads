#!/bin/sh
# List keywords
. "$(dirname "$0")/common.sh"

CAMPAIGN_ID=""
GROUP_ID=""
CSV_FILE=""
while [ $# -gt 0 ]; do
  case "$1" in
    --campaign-id) CAMPAIGN_ID="$2"; shift 2 ;;
    --group-id) GROUP_ID="$2"; shift 2 ;;
    --csv) CSV_FILE="$2"; shift 2 ;;
    *) shift ;;
  esac
done

if [ -z "$CAMPAIGN_ID" ] && [ -z "$GROUP_ID" ]; then
  echo "Usage: keywords.sh --campaign-id 123456 | --group-id 789 [--csv kw.csv]" >&2
  exit 1
fi

if [ -n "$GROUP_ID" ]; then
  SEL="\"AdGroupIds\":[$GROUP_ID]"
else
  SEL="\"CampaignIds\":[$CAMPAIGN_ID]"
fi

BODY="{\"method\":\"get\",\"params\":{\"SelectionCriteria\":{$SEL},\"FieldNames\":[\"Id\",\"Keyword\",\"AdGroupId\",\"Status\",\"State\",\"Bid\",\"ContextBid\",\"StrategyPriority\"]}}"
RESP=$(direct_request "keywords" "$BODY")

echo "$RESP" | python3 -c "
import json, sys
data = json.load(sys.stdin)
kws = data.get('result', {}).get('Keywords', [])
csv_file = '$CSV_FILE'

print(f'{'ID':<12} {'Группа':<12} {'Статус':<10} {'Ставка':>10} {'Ключевая фраза'}')
print('-' * 90)
for k in kws:
    kid = k['Id']
    gid = k.get('AdGroupId', '?')
    status = k.get('Status', '?')
    bid = k.get('Bid', 0)
    if bid: bid = f'{bid/1000000:.2f}₽'
    else: bid = 'авто'
    phrase = k.get('Keyword', '?')
    print(f'{kid:<12} {gid:<12} {status:<10} {str(bid):>10} {phrase}')
print(f'\nВсего: {len(kws)} ключевых фраз')

if csv_file:
    with open(csv_file, 'w', encoding='utf-8-sig') as f:
        f.write('ID;Группа;Статус;Ставка;Фраза\n')
        for k in kws:
            bid = k.get('Bid', 0)
            if bid: bid = f'{bid/1000000:.2f}'
            else: bid = 'авто'
            f.write(f'{k[\"Id\"]};{k.get(\"AdGroupId\",\"\")};{k.get(\"Status\",\"\")};{bid};{k.get(\"Keyword\",\"\")}\n')
    print(f'CSV: {csv_file}')
"
