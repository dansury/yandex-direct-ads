#!/bin/sh
# List campaigns with statuses, budgets, statistics
. "$(dirname "$0")/common.sh"

STATUS_FILTER=""
CSV_FILE=""
while [ $# -gt 0 ]; do
  case "$1" in
    --status) STATUS_FILTER="$2"; shift 2 ;;
    --csv) CSV_FILE="$2"; shift 2 ;;
    *) shift ;;
  esac
done

BODY='{"method":"get","params":{"SelectionCriteria":{},"FieldNames":["Id","Name","Status","State","StatusPayment","DailyBudget","StartDate","Statistics","Type"]}}'

RESP=$(direct_request "campaigns" "$BODY")

# Write response to temp file for python
_tmp=$(mktemp)
printf '%s' "$RESP" > "$_tmp"

_STATUS_FILTER="$STATUS_FILTER" _CSV_FILE="$CSV_FILE" python3 - "$_tmp" << 'PYEOF'
import json, sys, os

with open(sys.argv[1]) as f:
    data = json.load(f)
os.unlink(sys.argv[1])

camps = data.get('result', {}).get('Campaigns', [])
status_filter = os.environ.get("_STATUS_FILTER", "").upper()

lines = []
for c in camps:
    state = c.get('State', '?')
    if status_filter and status_filter != 'ALL' and state != status_filter:
        continue
    cid = c['Id']
    name = c.get('Name', '?')
    status = c.get('Status', '?')
    payment = c.get('StatusPayment', '?')
    budget = c.get('DailyBudget', {})
    if budget:
        amt = budget.get('Amount', 0) / 1000000
        mode = budget.get('Mode', '?')
        budget_str = "{:.0f}R ({})".format(amt, mode)
    else:
        budget_str = "не задан"
    stats = c.get('Statistics', {})
    impressions = stats.get('Impressions', 0)
    clicks = stats.get('Clicks', 0)
    lines.append((cid, name, status, state, payment, budget_str, impressions, clicks))

print("{:<12} {:<25} {:<12} {:<8} {:<12} {:<20} {:>8} {:>6}".format(
    'ID', 'Название', 'Статус', 'Сост.', 'Оплата', 'Бюджет/день', 'Показы', 'Клики'))
print('-' * 110)
for l in lines:
    print("{:<12} {:<25} {:<12} {:<8} {:<12} {:<20} {:>8} {:>6}".format(*l))
print("\nВсего: {} кампаний".format(len(lines)))

csv_file = os.environ.get("_CSV_FILE", "")
if csv_file:
    with open(csv_file, 'w', encoding='utf-8-sig') as f:
        f.write('ID;Название;Статус;Состояние;Оплата;Бюджет/день;Показы;Клики\n')
        for l in lines:
            f.write(';'.join(str(x) for x in l) + '\n')
    print("CSV: " + csv_file)
PYEOF
