#!/bin/sh
# Common functions for Yandex Direct API v5
set -e

SKILL_DIR="$(cd "$(dirname "$0")/.." && pwd)"
CONFIG_FILE="$SKILL_DIR/config/.env"
CACHE_DIR="$SKILL_DIR/cache"

mkdir -p "$CACHE_DIR"

load_config() {
  if [ -f "$CONFIG_FILE" ]; then
    . "$CONFIG_FILE"
  fi
  TOKEN="${YANDEX_DIRECT_TOKEN:-}"
  if [ -z "$TOKEN" ]; then
    echo "ERROR: YANDEX_DIRECT_TOKEN not set in $CONFIG_FILE" >&2
    exit 1
  fi
}

# JSON value extractor (simple, no deps)
json_value() {
  python3 -c "
import json,sys
d=json.load(sys.stdin)
keys='$1'.split('.')
for k in keys:
    if isinstance(d,list): d=d[int(k)]
    else: d=d[k]
if isinstance(d,(dict,list)): print(json.dumps(d,ensure_ascii=False))
else: print(d)
" 2>/dev/null
}

# POST request to Direct API
# Usage: direct_request <service> <json_body>
direct_request() {
  _service="$1"
  _body="$2"
  _url="https://api.direct.yandex.com/json/v5/${_service}"
  _attempt=0
  _max=3

  while [ "$_attempt" -lt "$_max" ]; do
    _resp=$(curl -s -w "\n%{http_code}" \
      -X POST "$_url" \
      -H "Authorization: Bearer $TOKEN" \
      -H "Accept-Language: ru" \
      -H "Content-Type: application/json" \
      -d "$_body")

    _code=$(echo "$_resp" | tail -1)
    _data=$(echo "$_resp" | sed '$d')

    case "$_code" in
      200) echo "$_data"; return 0 ;;
      429|500|502|503)
        _attempt=$((_attempt + 1))
        _wait=$((_attempt * 2))
        echo "Retry $_attempt/$_max (HTTP $_code), wait ${_wait}s..." >&2
        sleep "$_wait"
        ;;
      *)
        echo "ERROR: HTTP $_code" >&2
        echo "$_data" >&2
        return 1
        ;;
    esac
  done
  echo "ERROR: Max retries reached" >&2
  return 1
}

# Reports API (different endpoint, TSV response)
# Usage: direct_report <json_body>
direct_report() {
  _body="$1"
  _url="https://api.direct.yandex.com/json/v5/reports"
  _attempt=0
  _max=10

  while [ "$_attempt" -lt "$_max" ]; do
    _resp=$(curl -s -w "\n%{http_code}" \
      -X POST "$_url" \
      -H "Authorization: Bearer $TOKEN" \
      -H "Accept-Language: ru" \
      -H "Content-Type: application/json" \
      -H "processingMode: auto" \
      -H "returnMoneyInMicros: false" \
      -H "skipReportHeader: true" \
      -H "skipColumnHeader: false" \
      -H "skipReportSummary: true" \
      -d "$_body")

    _code=$(echo "$_resp" | tail -1)
    _data=$(echo "$_resp" | sed '$d')

    case "$_code" in
      200) echo "$_data"; return 0 ;;
      201|202)
        _attempt=$((_attempt + 1))
        _wait=5
        echo "Report building... retry $_attempt/$_max" >&2
        sleep "$_wait"
        ;;
      429|500|502|503)
        _attempt=$((_attempt + 1))
        sleep 3
        ;;
      *)
        echo "ERROR: HTTP $_code" >&2
        echo "$_data" >&2
        return 1
        ;;
    esac
  done
  echo "ERROR: Report timeout" >&2
  return 1
}

# Format micros to rubles
micros_to_rub() {
  python3 -c "print(f'{$1/1000000:.2f}')"
}

load_config
