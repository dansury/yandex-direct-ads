#!/bin/sh
# Account balance and shared account info
. "$(dirname "$0")/common.sh"

# Get campaigns with payment info to infer balance
BODY='{"method":"get","params":{"SelectionCriteria":{},"FieldNames":["Id","Name","State","StatusPayment","Funds"]}}'
RESP=$(direct_request "campaigns" "$BODY")

echo "$RESP" | python3 -c "
import json, sys
data = json.load(sys.stdin)
camps = data.get('result', {}).get('Campaigns', [])

print('=== Баланс по кампаниям ===\n')
for c in camps:
    name = c.get('Name', '?')
    funds = c.get('Funds', {})

    # Campaign funds (individual account)
    cf = funds.get('CampaignFunds', {})
    sf = funds.get('SharedAccountFunds', {})

    if sf:
        balance = sf.get('Balance', 0) / 1000000
        spend = sf.get('Spend', 0) / 1000000
        refund = sf.get('Refund', 0) / 1000000
        print(f'{name}:')
        print(f'  Общий счёт: баланс {balance:.2f}₽, расход {spend:.2f}₽, возврат {refund:.2f}₽')
    elif cf:
        balance = cf.get('Balance', 0) / 1000000
        limit_ = cf.get('BalanceBonus', 0) / 1000000
        spend = cf.get('SumAvailableForTransfer', 0) / 1000000
        print(f'{name}:')
        print(f'  Баланс: {balance:.2f}₽')
    else:
        payment = c.get('StatusPayment', '?')
        print(f'{name}: оплата={payment}, данные по фондам недоступны')
    print()
"
